
/**
 * Write a description of class TestProgram here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.io.*;
import java.util.*;
public class TestProgram
{
 public static void main(String[] args) {
        try {
            // this is the part were i load the words from file 
             List<String> words = new ArrayList<>();
             Scanner sc = new Scanner(new File("words10.txt"));// line to open and read line by line 
             while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();// i used trim to remore extra spaces 
                  if (line.length() == 10) {// this is the condition that add the word with 10 letters 
                    words.add(line);
                }
            }
            sc.close();//closing my file 
           Random generator = new Random();
           
           String selectedEntry = words.get(generator.nextInt(words.size()));
           // display the word 
           System.out.println("(Unmixed) Random Word : " + selectedEntry);
           
            MyArrayList<CharacterWrapper> wordCharacters = LoadWord.loadWord( selectedEntry);
            System.out.print("Secret Word: "); // this displays under scores of hidden word 
                 for (int i = 0; i < wordCharacters.size(); i++) {
                                System.out.print(wordCharacters.get(i)+" ");
                                    }
                                    System.out.println();
                                    
            LoadWord.shuffleWord(wordCharacters);
            System.out.print("Shuffled Word: ");
            int n=wordCharacters.size();
            for (int i = 0; i < n; i++) {
                System.out.print(wordCharacters.get(i).getLetter() + " "); 
            }
            System.out.println();
Scanner entry = new Scanner(System.in);
int Tries = 7;

while (Tries > 0) {
    // Display the current state of the word
    System.out.print("Current Word: ");
    
    for ( int i = 0;i < n; i++) {
        System.out.print(wordCharacters.get(i) + " ");
    }
    System.out.println();

    // Get the user's guess
    System.out.print("Enter your guess: ");
    String choice = entry.nextLine();

    if (choice.equalsIgnoreCase(selectedEntry)) {
        // User guessed the correct word
        System.out.println("Congratulations, You guessed the correct word");
        break;
    }

    
    wordCharacters.verifyWord(choice);

    if (wordCharacters.verifyWinner()) {
        System.out.println("You showed all letters,The word is: " + selectedEntry);
        break;
    }

    // Decrement Tries 
    Tries=Tries-1;

    if (Tries > 0) {
        wordCharacters.showHint(); // Provide a new hint
        System.out.println("Wrong; Tries left: " + Tries);
    } else {
        System.out.println("Unfortunately you have reached the End of the Game;The word was: " + selectedEntry);
    }
}
           
}catch (IOException ex) {
    System.err.println("Error!! cant read the file : " + ex.getMessage());
}
}
}