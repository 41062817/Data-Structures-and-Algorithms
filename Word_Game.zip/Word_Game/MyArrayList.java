
/**
 * Write a description of class MyArrayList here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MyArrayList<E>
{
     private int size; // Number of elements in the list
  private E[] data;
 
  public MyArrayList() {
       data = (E[])new Object[100];// cannot create array of generics
       size = 0; // Number of elements in the list
  }
  
  public void add(int Pos, E e) {   
    // Ensure the Pos is in the right range
    if (Pos < 0 || Pos > size)
      throw new IndexOutOfBoundsException
        ("Pos: " + Pos + ", Size: " + size); 
    
    for (int i = size - 1; i >= Pos; i--)
      data[i + 1] = data[i];
 
    data[Pos] = e;
    // Increase size by 1
    size++;
  }

  public boolean contains(Object e) {
    for (int i = 0; i < size; i++)
      if (e.equals(data[i])) return true;
    return false;
  }

  public E get(int Pos) {
    if (Pos < 0 || Pos >= size)
      throw new IndexOutOfBoundsException
        ("Pos: " + Pos + ", Size: " + size);
    return data[Pos];
  }
  
  public E remove(int Pos) {
    if (Pos < 0 || Pos >= size)
      throw new IndexOutOfBoundsException
        ("Pos: " + Pos + ", Size: " + size);
    E e = data[Pos];
   
    for (int j = Pos; j < size - 1; j++)
      data[j] = data[j + 1];
    data[size - 1] = null; 
    // Decrement size
    size--;
    return e;
  }

  public String toString() {
    String result=" ";
    for (int i = 0; i < size; i++) {
      result+= data[i];
      if (i < size - 1) result+=", ";
    }
    return result.toString() + "]";
  }

  
  public int size() {
    return size;
  }
  
 public boolean sortList() {
    E hold;
    for (int i = 0; i < size-1; i++)
     {
       for (int j = 0; j<size-1; j++)
        {       
         if(((Comparable)data[j]).compareTo(data[j+1])>0)
          {
           hold= data[j+1];
           data[j+1]=data[j];
           data[j]=hold;
          }       
       }
     }
    
     return true; 
    }
     
    public void swap(int Pos1, int Pos2) {
    if (Pos1 < 0 || Pos1 >= size) {
    throw new IndexOutOfBoundsException("Invalid Position1 for swap");
}

if (Pos2 < 0 || Pos2 >= size) {
    throw new IndexOutOfBoundsException("Invalid Position2 for swap");
}

    E swapper = data[Pos1];
    data[Pos1] = data[Pos2];
    data[Pos2] = swapper;
}
public void verifyWord(String guessedWord) {
        
    int limit = Math.min(size, guessedWord.length());
for (int i = 0; i < limit; i++) {
        CharacterWrapper current = (CharacterWrapper) data[i];
         if (Character.toLowerCase(current.getLetter()) == Character.toLowerCase(guessedWord.charAt(i))) {
            current.setDisclose(true); 
        }
    }
}
    
    
    
public boolean verifyWinner() {// checks if all letters in the word are shown 
    int i = 0;
    while (i < size) {
        if (!((CharacterWrapper) data[i]).isDisclose()) {
            return false;
        }
        i++;
    }
    return true;
}

public void showHint() {//shows one hidden random letter 
    java.util.Random rand = new java.util.Random();
    int index = rand.nextInt(size);
    while (((CharacterWrapper) data[index]).isDisclose()) {
        index = rand.nextInt(size);
    }
    ((CharacterWrapper) data[index]).setDisclose(true);//shows hidden letter 
}
}
  



 