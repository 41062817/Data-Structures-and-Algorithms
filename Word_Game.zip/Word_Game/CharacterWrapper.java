
/**
 * Write a description of class CharacterWrapper here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CharacterWrapper
{
   
    // Character Wrapper variables 
    private char Letter;
    private boolean disclose;

    public CharacterWrapper(char Letter) {// constructor
        this.Letter = Letter;
        this.disclose = false;
    }
     public char getLetter() { return Letter;}// method to receive word 
       
    public void setDisclose(boolean disclose) {
        this.disclose = disclose;
    }
    public boolean isDisclose() {return disclose;}
        
     @Override
    public String toString() {// my toSring method to display under Scores of hidden word 
        if (disclose) {
                return String.valueOf(Letter);
       } else {
                     return "_";
}
    }
}
