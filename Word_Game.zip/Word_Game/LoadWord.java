
/**
 * Write a description of class LoadWord here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */import java.util.Random;
public class LoadWord
{
public static MyArrayList<CharacterWrapper>  loadWord(String text){//loadWord() method
            MyArrayList<CharacterWrapper> collection = new MyArrayList<>();
for (int i = 0; i < text.length(); i++) {
            collection.add(i, new CharacterWrapper(text.charAt(i)));
        }
        return collection;// returning the list 
    }
    //shuffleWord  method that randomly shuffles the characters of a word
       public static void shuffleWord(MyArrayList<CharacterWrapper> collection) {
        Random rand = new Random();
        int n=collection.size();
        

        for ( int i=0;i < n; i++) {
            int randomIndex = rand.nextInt(n);
            collection.swap(i, randomIndex); // swapping Positions 
        }
    }
}
    