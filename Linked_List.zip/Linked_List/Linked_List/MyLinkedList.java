/**
 * A simple implementation of a singly linked list.
 *
 * @author 
 * @version 
 */
public class MyLinkedList<E>
{
    private Node<E> head, tail;

    public MyLinkedList() {
        head = null;
        tail = null;
    }

    /** Return the head element in the list */
    public E getFirst() {
        if (head == null) {
            return null;
        }
        else {
            return head.element;
        }
    }

    /** Return the last element in the list */
    public E getLast() {
        if (head == null) {
            return null;
        }
        else {
            return tail.element;
        }
    }

    /** Add an element to the beginning of the list */
    public void prepend(E e) {
        Node<E> newNode = new Node<>(e); 
        newNode.next = head;  
        head = newNode;  
        if (tail == null) {  
            tail = head;
        }
    }

    /** Add an element to the end of the list */
    public void append(E item) {
        Node<E> newNode = new Node<>(item);  
        if (head == null) {
            head = tail = newNode;  
        }
        else {
            tail.next = newNode;  
            tail = newNode;  
        }
    }

    /** Remove the head node and return its element */
    public E removeFirst() {
        if (head == null) {
            return null;
        }
        else {
            E temp = head.element;
            head = head.next;
            if (head == null) {
                tail = null;
            }
            return temp;
        }
    }

    /** Delete the first occurrence of an item */
    public boolean delete(E item) {
        Node<E> ptr = head;
        Node<E> prvPtr = null;

        while (ptr != null && ((Comparable)ptr.element).compareTo(item) != 0) {
            prvPtr = ptr;
            ptr = ptr.next;
        }

        if (ptr == null) // not found
            return false;

        if (ptr == head) // deleting head
            head = head.next;
        else
            prvPtr.next = ptr.next;

        if (ptr == tail) // deleting tail
            tail = prvPtr;

        return true;
    }

    /** Convert the list to a string */
    public String toString() {
        String result = "[";
        Node<E> ptr = head;
        while (ptr != null) {
            result += ptr.element.toString();
            if (ptr.next != null) {
                result += ",";
            }
            ptr = ptr.next;
        }
        result += "]";
        return result;
    }

    /** Clear the list */
    public void clear() {
        head = tail = null;
    }

    

    /** Node class */
    private static class Node<E> {
        E element;
        Node<E> next;

        public Node(E element) {
            this.element = element;
            next = null;
        }
    }
    // My method to remove dublicates 
    public void removeDuplicate() {
        for (Node<E> current = head; current != null; current = current.next) {
            Node<E> previous = current;
            for (Node<E> pointer = current.next; pointer != null; ) {
                Comparable checkVal = (Comparable) current.element;
                
                if (checkVal.compareTo(pointer.element) == 0) {
                    
                    previous.next = pointer.next;
                    if (pointer == tail) {
                        tail = previous;
                    }
                    pointer = pointer.next;
                } else {
                    previous = pointer;
                    pointer = pointer.next;
                }
            }
        }
    }
}// end myLinkedList class
