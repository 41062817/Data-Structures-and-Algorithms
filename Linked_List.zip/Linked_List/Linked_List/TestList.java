
/**
 * Write a description of class test here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

    public class TestList {
    public static void main(String[] args) {
        MyLinkedList<Integer> list = new MyLinkedList<>();

        // add elements including duplicates
        list.append(1);
        list.append(2);
        list.append(3);
        list.append(4);
        list.append(5);
        list.append(4);
        list.append(3);
        list.append(1);
        list.append(2);
        list.append(3);
        list.append(4);
        list.append(1);

        System.out.println("Before: " + list.toString());

        list.removeDuplicate();

        System.out.println("After:  " + list.toString());
    }
}


