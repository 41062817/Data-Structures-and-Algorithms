
/**
 * Write a description of class Business here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Business implements Comparable<Business> //  My Own class that implements Comparable
                                                      // Used to test recursion in MyArrayList
{
   private String name;
    private double revenue; // yearly revenue

    public Business(String name, double revenue) {
        this.name = name;
        this.revenue = revenue;
    }

    // Compare businesses by revenue
    @Override
    public int compareTo(Business other) {
        return Double.compare(this.revenue, other.revenue);
    }

    @Override
    public String toString() {
        return name + " (Revenue: " + revenue + "M)";
    }

}
