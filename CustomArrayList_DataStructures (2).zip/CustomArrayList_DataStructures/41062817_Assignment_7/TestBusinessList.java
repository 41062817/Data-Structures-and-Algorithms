
/**
 * Write a description of class TestMyArrayList here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestBusinessList
{
     public static void main(String[] args) {
        MyArrayList<Business> businesses = new MyArrayList<>();
        System.out.println("TEST WITH EMPTY LIST:" + businesses);
        
        businesses.findMaxRecursive(); 

        businesses.add(0, new Business("TechCorp", 120.5));
        businesses.add(1, new Business("Foodies", 85.3));
        businesses.add(2, new Business("AutoWorks", 200.0));
        businesses.add(3, new Business("MediCare", 150.7));
        businesses.add(4, new Business("GreenEnergy", 175.9));

        System.out.println("Business List: " + businesses);

        // Test recursive method
        System.out.println("Top Business: " + businesses.findMaxRecursive());

        // Special case: one element
        MyArrayList<Business> single = new MyArrayList<>();
        single.add(0, new Business("StartupX", 15.0));
        System.out.println("Single Business List: " + single);
        System.out.println("Top Business (Single): " + single.findMaxRecursive());
    }
}
    

