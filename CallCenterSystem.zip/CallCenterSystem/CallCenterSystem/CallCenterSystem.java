
/**
 * Write a description of class CallCenterSystem here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CallCenterSystem
{
 private QueueAsMyLinkedList<String> calls;
 private StackAsMyLinkedList<String> history;

    public CallCenterSystem() {
        calls = new QueueAsMyLinkedList<>();
        history = new StackAsMyLinkedList<>();
    }

    public void addCall(String details) {
        calls.enqueue(details);
        System.out.println("Added to queue -> " + details);
    }

    public void answerCall() {
        String current = calls.dequeue();
        if (current == null) {
            System.out.println("No pending calls right now.");
        } else {
            history.push(current);
            System.out.println("Handling call -> " + current);
        }
    }

    public void undoCall() {
        String last = history.pop();
        if (last == null) {
            System.out.println("Nothing to undo.");
        } else {
            calls.enqueue(last);
            System.out.println("Moved back to queue -> " + last);
        }
    }

    public void showSystem() {
        System.out.println(calls.toString());
        System.out.println(history.toString());
    }
}   

