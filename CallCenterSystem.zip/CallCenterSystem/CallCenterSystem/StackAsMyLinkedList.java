
/**
 * Write a description of class StackAsMyLinkedList here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class StackAsMyLinkedList<E> {
    private MyLinkedList<E> records; //declaring my linked list 

    public StackAsMyLinkedList() {
        records = new MyLinkedList<>();
    }

    public void push(E item) {
        records.prepend(item);
    }

    public E pop() {// add my item to beginning of the list 
        E topItem = records.getFirst();
        if (topItem != null && records.delete(topItem)) {
            return topItem;
        }
        return null;
    }

    public int size() {
        int count = 0;
    String listString = records.toString(); 
    if (!listString.equals("[]")) {
        count = listString.split(",").length;
    }
    return count;
    }

    public boolean isEmpty() {
        return records.getFirst() == null;
    }

    public String toString() {
        return "[Resolved History] " + records.toString();
    }
}