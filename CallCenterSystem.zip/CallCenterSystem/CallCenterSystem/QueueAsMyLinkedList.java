
/**
 * Write a description of class QueueAsMyLinkedList here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class QueueAsMyLinkedList<E> {
    private MyLinkedList<E> line;

    public QueueAsMyLinkedList() {
        line = new MyLinkedList<>();
    }

    public void enqueue(E data) {  // insert at the end 
        line.append(data);
    }

    public E dequeue() {  // remove the first one 
        E peek = line.getFirst();
        if (peek != null && line.delete(peek)) {
            return peek;
        }
        return null;
    }

    public boolean isEmpty() {
        return line.getFirst() == null;
    }

    public int size() {
        String list = line.toString(); 
    if (list.equals("[]")) {
        return 0;
    }
    return list.split(",").length;
    }

    public String toString() {
        return "[Waiting List] " + line.toString();
    }
}
