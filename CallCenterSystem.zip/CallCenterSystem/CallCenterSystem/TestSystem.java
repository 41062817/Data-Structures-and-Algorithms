
/**
 * Write a description of class TestSystem here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestSystem
{
   
    public static void main(String[] args) {
        CallCenterSystem desk = new CallCenterSystem();

        desk.addCall("Call A: Network issue");
        desk.addCall("Call B: Payment query");
        desk.addCall("Call C: Upgrade request");
      

        desk.showSystem();

        desk.answerCall();
        desk.answerCall();
        desk.showSystem();

        desk.undoCall();
        desk.showSystem();

        desk.answerCall();
        desk.answerCall();
        desk.answerCall(); 

        desk.showSystem();
    }
}

